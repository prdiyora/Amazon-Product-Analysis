# Amazon Product Analysis

Aa Chrome Manifest V3 extension Amazon India (`amazon.in`) athva USA (`amazon.com`) ni current category ke search-results page parthi maximum 50 unique non-sponsored products collect kare chhe. Google Sheetma rows `Bought Count` highest ane tie hoy tyare `Review Count` lowest orderma save thay chhe.

## Current-page analysis

Amazon par manually category kholo athva brand/product keyword search ane required filters apply karo. Pachhi result page par extension open kari direct `Start analysis` dabavo. Extension koi duplicate search box ke mode-selection vagar active Amazon page ni visible listing ane pagination scrape kare chhe.

## Dynamic analysis tabs

`Analysis tab name` optional chhe. Blank hoy to selected marketplace nu default tab use thase:

- India -> `Amazon Products IN`
- USA -> `Amazon Products USA`

Custom name aapo to extension selected marketplace pramane suffix add kare chhe:

- `Umbrella Analysis` + India -> `Umbrella Analysis - IN`
- `Umbrella Analysis` + USA -> `Umbrella Analysis - USA`

Same analysis name fari use karsho to nava run ni badhi product rows tabna endma append thase; same ASIN no previous run snapshot preserve rahese. Same runni progressive save ke Retry Upload duplicate banavvane badle existing run row update karse. Custom analysis tabs default `Amazon Products IN/USA` tabs thi alag rahese.

Darek analysis run ni product rows ek consistent light background color use kare chhe. Runs chronological blocksma rahe chhe ane next run guaranteed next light color use karse. Darek runni andar products `Bought Count` highest ane tie par `Review Count` lowest pramane sort thase. Empty separator rows add nathi thata.

## Data columns

Run timestamp, category URL/name, full category path, ASIN, title, brand, product URL, price, numeric price, currency, rating, review count, bought text/count, scrape status, error ane marketplace.

`Category Path` breadcrumb formatma save thase, jem ke `Home & Kitchen›Kitchen & Dining›Kitchen Tools›Oil Preparation & Dispensers›Oil Sprayers`.
Amazon search page mate `Category Name` ma `Search: keyword` ane `Category Path` ma `Amazon Search›keyword` save thase; Amazon na unrelated `Subtotal` headings ignore thase.

`Bought Count` Amazon par display thata approximate text (jem ke `1K+ bought in past month`) par based chhe. Amazon aa value darek product mate batavtu nathi; eva product sortingma niche aavse.

## 1. Google Sheet ane Apps Script setup

1. Darek user mate dedicated navi Google Sheet create karo. Aa Sheetma biju important data na rakho.
2. Sheetma `Extensions > Apps Script` open karo.
3. Default code delete kari `apps-script/Code.gs` nu code paste karo.
4. Apps Script editorna function dropdownma `configureTargetSpreadsheet` select kari `Run` karo ane permissions allow karo. Aa current Sheet ID deployment mate save karse.
5. `Deploy > New deployment > Web app` select karo.
6. `Execute as: Me` ane access `Anyone` set kari deploy karo.
7. Maleli `https://script.google.com/macros/s/.../exec` URL extension popupna `Apps Script Web App URL` fieldma paste karo.

Apps Script darek deploymentne `configureTargetSpreadsheet` vakhte active hati e Sheet sathe bind kare chhe. Etle alag userni alag Sheet ane alag `/exec` URL rahese. Setup vakhte fakt default `Amazon Products IN` tab banse. `Amazon Products USA` tab first USA run vakhte j banse. Custom named analysis run potana `Name - IN/USA` tabma j data lakhse.

Apps Script existing `Amazon Products IN/USA`, custom analysis ane unrelated tabs/data delete ke rename kartu nathi. Requested custom tab pehla thi unrelated headers/data sathe exist karto hoy to overwrite karvane badle clear error aapse.

Darek runma `Run Timestamp + Marketplace + ASIN` unique key chhe. Etle upload Retry safe chhe, pan pachhina runma same ASIN ave to history mate navo snapshot row append thase. ASIN missing hoy to same run timestamp + marketplace + product URL fallback key chhe.

Code update karya pachi existing Apps Script deploymentma `Deploy > Manage deployments > Edit > New version > Deploy` karvu jaruri chhe. Khali editor save karvathi old `/exec` deployment update nathi thatu.

## 2. Extension install

1. Aa folderma `npm install` ane `npm test` run karo.
2. Chrome ma `chrome://extensions` open karo.
3. `Developer mode` enable karo.
4. `Load unpacked` click kari aa project folder select karo.
5. Extension pin karo.

## 3. Scraping run

1. Popupma `Amazon India (.in)` ke `Amazon USA (.com)` select karo.
2. Optional `Analysis tab name` enter karo. Blank hoy to live preview default `Amazon Products IN/USA` batavse.
3. Potani Apps Script `/exec` URL paste karo.
4. Amazon par required category kholo athva brand/product search ane filters set karo.
5. Aa category/search-results page par extension open kari `Start analysis` dabavo.
6. Popup close kari shakay; fari open karta current progress dekhase.

Extension pagination follow kari 50 products collect karva try karse. Pages khuti jay to available products j upload thase. Product HTTP fetch blocked/incomplete hoy to extension ek temporary inactive tab open kari parse karse ane pote create karelo tab j close karse.

Darek 10 completed products pachi progressive save same named analysis tabma thase. Run complete thay tyare popup new/updated/failed/missing price/missing bought summary batavse ane `Open Sheet` button exact custom analysis tab kholse. Progressive save fail thay to already-saved batches safe rahese ane pending batch `Retry Upload`thi same original tabma mokli shakay.

`Open Sheet` button successful upload pachi j enable thase. Endpoint badalsho to navi deployment par successful upload thay tya sudhi old Sheet open nahi thay.

## Reliability ane limitations

- Amazon markup badlai shake chhe; selectors `src/parsers`ma centralized chhe.
- Requests low concurrency ane delay sathe chale chhe, etle 50 productsma thodo samay lagse.
- CAPTCHA/robot check bypass nathi thatu. Eva case ma run stop/fail thai shake ane Amazon tabma manual verification karvu padse.
- Logged-in account par automation mate zero-risk guarantee nathi. Separate Chrome profile/logged-out session, limited manual runs ane reasonable request volume safer chhe.
- Scraping complete pan upload fail thay to popupma `Retry Upload` thi cached rows fari mokli shakay.
- Fatal error ave to popup stage, error code, HTTP status, time ane suggested fix batavse. `Copy diagnostics` sensitive payload vagar troubleshooting details copy karse.
- Individual product parse/fetch issues popupma ASIN sathe batavse ane Sheetna `Status`/`Error` columnsma pan save thase.
- Amazon terms ane applicable rules follow kari personal, reasonable-volume use karo.

## Tests

```powershell
npm test
```

Tests sanitized fixtures par sponsored exclusion, pagination, product fields, blocked-page detection, count normalization ane final sorting verify kare chhe.
